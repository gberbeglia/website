Electronic companion of the paper:

Berbeglia, Gerardo and Garassino, Agust�n and Vulcano, Gustavo, A 
Comparative Empirical Study of Discrete Choice Models in Retail Operations (First version: March, 2018, Second version: July 2019). 
Available at SSRN: https://ssrn.com/abstract=3136816 or http://dx.doi.org/10.2139/ssrn.3136816

Authors and affiliations:
- Gerardo Berbeglia: Melbourne Business School, University of Melbourne, g.berbeglia@mbs.edu
- Agustin Garassino: School of Sciences, Universidad de Buenos Aires, and School of Business, Universidad Torcuato di Tella, Buenos Aires, Argentina, agarassino@dc.uba.ar
- Gustavo Vulcano: School of Business, Universidad Torcuato di Tella, and CONICET, Buenos Aires, Argentina, gvulcano@utdt.edu

The Generalized Stochastic Preferences synthetic instances used in this work can be found in the folder named "GSP_instances".
(For futher reading on the GSP, see: Berbeglia, G. The generalized stochastic preference choice model, 2018. ArXiv.)

The type of instance is encoded in the name. For example, the instance 50m_10l_30p_10x1s_small_12i.csv has the following properties:

- 50% of market share (50m)
- 10 lists (10l)
- 30 periods (30p)
- 10 products (10x1)
- Assortment size per period is between 3 and 6 (small)
- It is the 12^th instance of this type (12i)

60 instances can be found for each type, the valid combinations are:

Each file is a .csv and each row is a transaction (except the first row that contains the header).

The first number on each row indicates the purchased product, the remaining binary numbers encode the assortment being offered (observe that the product 0 (no-choice) is always offered).


Impact on revenue experiments:
The prices associated to each product for these experiments are as follows. These prices remain fixed for all instances.
Product 0: $0.0 (no-choice)
Product 1: $4.69
Product 2: $8.99
Product 3: $14.99
Product 4: $9.99
Product 5: $15.99
Product 6: $13.99
Product 7: $10.99
Product 8: $14.99
Product 9: $15.99
Product 10: $9.99
